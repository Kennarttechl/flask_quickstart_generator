DEMO_CSS =\
""" 

"""

REGISTER_LOGIN_CSS =\
""" 

"""

BASE_CSS =\
""" 
html,
body {
  height: 100%;
  margin: 0px;
  padding: 0px;
  font-family: Arial, sans-serif;
  transition: opacity 0.7s ease-in-out;
}
"""